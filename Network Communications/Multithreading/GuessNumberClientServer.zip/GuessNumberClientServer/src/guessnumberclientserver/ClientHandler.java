/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guessnumberclientserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author aimar
 */
public class ClientHandler extends Thread {

    private Socket clientSocket;
    private int targetNumber;
    private int round;
    private boolean alguienHaAcertado;

    public ClientHandler(Socket clientSocket, int targetNumber) {
        this.clientSocket = clientSocket;
        this.targetNumber = targetNumber;
        this.round = 0;
    }

    public int getRound() {
        return round;
    }

    public void setRound(int round) {
        this.round = round;
    }

    public boolean isAlguienHaAcertado() {
        return alguienHaAcertado;
    }

    public void setAlguienHaAcertado(boolean alguienHaAcertado) {
        this.alguienHaAcertado = alguienHaAcertado;
    }

    public void run() {
        try {
            InputStream inputStream = clientSocket.getInputStream();
            OutputStream outputStream = clientSocket.getOutputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            PrintWriter writer = new PrintWriter(outputStream, true);

            String clientMessage = reader.readLine();
            while (alguienHaAcertado == false) {
                try {
                    int guess = Integer.parseInt(clientMessage);
                    if (guess == targetNumber) {
                        writer.println("yes|" + round);
                        System.out.println("Client Guessed Right in round " + round);
                        System.exit(0);  // Terminar el programa
                    } else {
                        writer.println("no|" + round);
                    }
                } catch (NumberFormatException e) {
                    writer.println("Invalid input. Please send a valid number.");
                }

            }
          

        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            if(clientSocket!=null){
                try { 
                    clientSocket.close();
                } catch (IOException ex) {
                    Logger.getLogger(ClientHandler.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
             
        }
    }
}
