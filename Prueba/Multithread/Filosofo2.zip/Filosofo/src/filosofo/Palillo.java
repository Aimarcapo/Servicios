package filosofo;

public class Palillo {


  
  
    

  

}
