/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guessnumberclientserver;

/**
 *
 * @author aimar
 */
import java.io.*;
import java.net.*;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Server {

    private static boolean haAcertado;

    public static void main(String[] args) throws IOException {
        final int port = 12345;
        InetAddress localHost = InetAddress.getLocalHost();
        System.out.println("Server is waiting for a connection on " + localHost.getHostAddress() + ":" + port);
        ServerSocket serverSocket = new ServerSocket(port, 4);
        Random rand = new Random();
        while (true) {
            //Inicio de partida
            //Generacion de numeros random
            int rand_int = rand.nextInt(1, 10);
            System.out.println("Target number: " + rand_int);
            //Creacion de los trabajadores
            ClientHandler[] workers = new ClientHandler[4];
            for (int i = 0; i < 4; i++) {
                Socket clientSocket = serverSocket.accept();
                ClientHandler clientHandler = new ClientHandler(clientSocket, rand_int);
                clientHandler.start();
                workers[i] = clientHandler;
            }
            //Comienzo de las rondas
            int round = 0;
            while (true) {
                //Comienzo de una ronda
                round++;
                //Aviso a todos que el nuevo round es el que corresponda
                for (int i = 0; i < workers.length; i++) {
                    workers[i].setRound(round);
                }
                haAcertado = false;
                //Esperar las respuestas de los 4 clientes
                for (int i = 0; i < 4; i++) {
                    if (haAcertado == true) {
                        break;
                    }
                }
                //Si se acierta termina la ronda y la partida,sino se sigue la siguiente ronda
                if (haAcertado == true) {
                    break;
                }
            }
            //Alguien ha acertado, la partida se ha terminado y
            //hay que avisar a los trabjadores que se mueran y que cierren el socket del cliente
            for (int i = 0; i < workers.length; i++) {
                workers[i].setAlguienHaAcertado(true);
            }
        }
    }
}
