/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package guessnumberclientserver;

/**
 *
 * @author aimar
 */
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) throws UnknownHostException, IOException {
        final int port = 12345;
        Scanner in = new Scanner(System.in);
        InetAddress serverAddress = InetAddress.getLocalHost();

        Socket socket = new Socket(serverAddress, port);
        InputStream inputStream = socket.getInputStream();
        OutputStream outputStream = socket.getOutputStream();

        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        PrintWriter writer = new PrintWriter(outputStream, true);
        int i = 0;
        while (true) {
            System.out.println("Enter your guess (round " + (i + 1) + "):");
            int guess = in.nextInt();
            writer.println(guess);
            String serverResponse = reader.readLine();
            String[] respuesta = serverResponse.split("|");
            i = Integer.parseInt(respuesta[1]);
            if (respuesta[0].equals("yes")) {
                System.out.println("Congratulations you have guessed in round " + respuesta[1]);
                socket.close();
                break;
            } else {
                System.out.println("Round " + respuesta[1] + " sorry try it again.");
            }

        }
    }
}
